# Growth OS for Claude Cowork — Project Instructions

> This is the operational guide Claude reads on every session. It tells Claude where everything is, what's been set up, and what rules to follow.

Last updated: [DATE]

---

## What This Workspace Is

This is the Growth OS for Claude Cowork workspace for **[BUSINESS_NAME]**. It contains business context, audience profiles, and routines that Claude uses to produce content, answer questions, and support daily operations.

The owner is **[USER_NAME]**.

---

## Core Documents

| File | What It Contains | Status |
|---|---|---|
| `core/offers.md` | Products, pricing, and positioning | [STATUS] |
| `core/persona.md` | Ideal customer persona with pain/pleasure quotes | [STATUS] |
| `core/business-info.md` | Business identity, mission, team, channels | [STATUS] |
| `core/brand-voice.md` | Writing style guide | [STATUS] |
| `core/brand-design.md` | Visual identity (colors, fonts, layout) | [STATUS] |
| `core/content-rules.md` | Global writing standards | [STATUS] |

---

## Routines

| Routine | Trigger | File |
|---|---|---|
| Morning Routine | "good morning", "gm", "morning" | `routines/morning-routine.md` |

When [USER_NAME] says "good morning" (or any variation), immediately run the morning routine. Do not ask for confirmation.

---

## Quick Reference

- **Business:** [BUSINESS_NAME]
- **Primary offer:** [PRIMARY_OFFER_NAME] ([PRICE])
- **Audience:** [PERSONA_NAME] — [ONE_LINE_DESCRIPTION]
- **Website:** [WEBSITE_URL]

---

## Folder Structure

```
[workspace root]/
├── CLAUDE.md                 ← THIS FILE
├── progress.md               ← Setup progress tracker
├── core/
│   ├── offers.md             ← Products and pricing
│   ├── persona.md            ← Ideal customer persona
│   ├── business-info.md      ← Business identity and context
│   ├── brand-voice.md        ← Writing voice guide
│   ├── brand-design.md       ← Visual identity
│   └── content-rules.md      ← Global writing rules
├── routines/
│   └── morning-routine.md    ← Daily briefing
├── workflows/                ← (Ready for future skills and automations)
├── memory/
│   └── glossary.md           ← Quick decoder
└── .claude/
    └── commands/
        └── morning-routine.md
```

---

## Memory (Quick Decoder)

[GLOSSARY_ENTRIES]

---

## Global Rules

[CONTENT_RULES_IF_CONFIGURED]

---

## Setup Status

Quick Start Tier 1: [COMPLETE/IN PROGRESS]
Enhancements configured: [LIST_OF_COMPLETED_TIER_2_ITEMS]

To continue setup or add enhancements, say "enhance my workspace" or "continue setup."
