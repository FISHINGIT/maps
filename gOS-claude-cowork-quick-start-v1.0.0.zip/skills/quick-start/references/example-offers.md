# Products & Offers — Greenline Digital

> This document is the reference Claude reads whenever it needs to understand what we sell, who it's for, and how to position it. Keep it updated when pricing or packaging changes.

Last updated: February 2026

---

## Primary Offer

### Greenline Growth Accelerator

**What it is:** A 12-week group coaching program that helps B2B SaaS founders build a repeatable demand-generation engine using content marketing and AI tools.

**Who it's for:** B2B SaaS founders doing $500K-$5M ARR who have product-market fit but struggle to generate consistent pipeline beyond founder-led sales.

**Pricing:** $4,500 (one-time) or 3 payments of $1,650

**What's included:**
- 12 weekly live group coaching calls (90 min each)
- AI-powered content system setup (Claude workspace + templates)
- Custom messaging framework built during Week 1
- Private Slack community with async coaching
- Lifetime access to recordings and templates

**Primary CTA:** "Apply for the next cohort" (application form, not open enrollment)

**Positioning:** This is NOT another marketing course. It is a hands-on build where you leave with a working system, not a notebook full of theory.

---

## Secondary Offer

### Greenline Content Audit

**What it is:** A one-time deep audit of existing content (website, blog, LinkedIn, email) with a prioritized action plan.

**Who it's for:** Same audience as the Accelerator. Often serves as a stepping stone to the full program.

**Pricing:** $1,200

**What's included:**
- Full content audit across all active channels
- Competitor content benchmarking (3 competitors)
- 90-day content roadmap with weekly themes
- 60-minute strategy call to walk through findings

**Positioning:** "Find out what's working, what's wasting your time, and where the easy wins are hiding."

---

## Free Offer (Lead Magnet / Top of Funnel)

### The Greenline Weekly

**What it is:** A free weekly newsletter covering B2B content strategy, AI tools, and founder marketing lessons.

**Who it's for:** B2B SaaS founders and marketing leads interested in content-driven growth.

**Frequency:** Weekly (Tuesdays)

**Positioning:** Practical, opinionated, short. Not a link roundup. Every issue teaches one thing you can use that week.

**CTA to primary offer:** Soft mentions in the newsletter (no hard sells). Annual open enrollment promoted 2x/year.

---

## Offer Hierarchy

```
The Greenline Weekly (free) → Content Audit ($1,200) → Growth Accelerator ($4,500)
```

All content should ultimately drive awareness of the Greenline Growth Accelerator. The Content Audit is the low-commitment entry point for prospects who aren't ready for the full program.
