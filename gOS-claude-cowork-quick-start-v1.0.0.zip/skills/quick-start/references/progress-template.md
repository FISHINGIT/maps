# Growth OS for Claude Cowork — Quick Start Progress

> This file tracks your setup progress across sessions. Claude reads it at the start of every session to know where you left off.

Started: [DATE]
Last updated: [DATE]

---

## Tier 1: Core Setup (Required)

- [ ] **Quick Intake** — Name, business name, website crawled
- [ ] **Offers Document** — Products, pricing, and positioning (`core/offers.md`)
- [ ] **Persona Document** — Ideal customer with pain/pleasure quotes (`core/persona.md`)
- [ ] **Morning Routine** — Personalized daily briefing (`routines/morning-routine.md`)
- [ ] **CLAUDE.md Generated** — Operational guide created
- [ ] **Quick Start Complete** — All Tier 1 items finished

## Tier 2: Enhancements (Optional)

- [ ] **Business Info** — Full business context (`core/business-info.md`)
- [ ] **Brand Voice** — Writing style guide (`core/brand-voice.md`)
- [ ] **Brand Design** — Visual identity guide (`core/brand-design.md`)
- [ ] **Content Rules** — Global writing standards (`core/content-rules.md`)

---

## Session Log

| Date | What was completed |
|---|---|
| [DATE] | [What happened] |
