# Brand Design Guide — Greenline Digital

> This document defines the visual identity for all design output. Claude reads this before producing HTML, slides, emails, or any visual assets.

Last updated: February 2026

---

## Design Philosophy

Clean, modern, confident. The design should feel like a well-organized workspace, not a flashy landing page. White space is a feature, not a bug. Every visual element earns its place.

## Color Palette

### Primary Colors

| Name | Hex | RGB | Usage |
|---|---|---|---|
| Greenline Green | #2D8C5A | 45, 140, 90 | Primary brand color. Buttons, headings, accents |
| Dark Slate | #1E293B | 30, 41, 59 | Primary text color |
| White | #FFFFFF | 255, 255, 255 | Backgrounds |

### Secondary Colors

| Name | Hex | RGB | Usage |
|---|---|---|---|
| Light Green | #E8F5E9 | 232, 245, 233 | Callout backgrounds, highlights |
| Warm Gray | #F8FAFC | 248, 250, 252 | Section backgrounds, cards |
| Medium Gray | #64748B | 100, 116, 139 | Secondary text, captions |

### Accent Colors

| Name | Hex | Usage |
|---|---|---|
| Alert Orange | #F59E0B | Warnings, attention items |
| Success Blue | #3B82F6 | Links, success states |
| Error Red | #EF4444 | Errors, critical items |

## Typography

| Role | Font | Weight | Size |
|---|---|---|---|
| Headings | Inter | Bold (700) | H1: 36px, H2: 28px, H3: 22px |
| Body | Inter | Regular (400) | 16px, line-height 1.6 |
| Small text | Inter | Regular (400) | 14px |
| Code/monospace | JetBrains Mono | Regular (400) | 14px |

## Layout Rules

- Maximum content width: 720px for text-heavy pages
- Section padding: 48px vertical
- Card border-radius: 8px
- Card shadow: 0 1px 3px rgba(0,0,0,0.1)
- Button border-radius: 6px
- Button padding: 12px 24px

## Logo Usage

- Primary logo: dark text on light backgrounds
- Inverted logo: white text on dark or green backgrounds
- Minimum clear space: 1x the height of the logo mark on all sides
- Never stretch, rotate, or change the logo colors

## Do's and Don'ts

**Do:**
- Use generous white space
- Keep layouts simple and scannable
- Use the green as an accent, not a dominant color
- Maintain consistent spacing (multiples of 8px)

**Don't:**
- Use gradients on text
- Mix more than 3 colors in a single layout
- Use stock photos that look like stock photos
- Put text over busy backgrounds
