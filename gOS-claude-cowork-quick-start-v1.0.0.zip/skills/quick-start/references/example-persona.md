# Ideal Customer Persona — Greenline Digital

> This document defines who we create content for, what language resonates with them, and what motivates them to act. Claude reads this before writing any audience-facing content.

Last updated: February 2026

---

## Meet Alex

**Full archetype:** Alex, the Pipeline-Hungry Founder

**Demographics:** 35-50 years old. Founded or co-founded a B2B SaaS company doing $500K-$5M ARR. Technical or product background. Has 5-30 employees. Based in the US, often remote-first.

**One-line description:** A SaaS founder who's proven the product works but can't break out of founder-led sales into scalable, predictable pipeline.

---

## What Alex Wants

- Predictable pipeline that doesn't depend on the founder being in every sales conversation
- A content engine that generates inbound leads while the founder focuses on product and team
- Proof that content marketing actually works for B2B SaaS (not just "build an audience and hope")
- Simple systems, not complex martech stacks with 12 tools and 3 agencies

## What Frustrates Alex

- Hired a marketing person or agency and got blog posts nobody reads
- Knows content marketing "works" but can't figure out HOW for their specific product
- LinkedIn feels like shouting into a void
- Every marketing resource is built for consumer brands or massive enterprises, not $2M SaaS companies
- Has tried AI tools but gets generic, bland output that sounds nothing like them

---

## Pain Points with Quote Tables

Each pain point includes quotes written in Alex's voice, showing what they say when struggling (pain) and what they would say once the problem is solved (pleasure).

### Pain Point 1: Founder is the entire sales and marketing department

| Pain Quote | Pleasure Quote |
|---|---|
| "I'm the best salesperson we have and that's the whole problem." | "Three demos booked this week from content I didn't personally write or post." |
| "I can't grow the company if I'm stuck doing all the selling." | "My Tuesday newsletter generates more qualified leads than my last SDR did." |
| "Every hour I spend on LinkedIn is an hour I'm not building product." | "I batch my content on Monday mornings and the system handles distribution all week." |
| "We have a marketing person but I still end up writing everything because they don't get our product." | "My content system captures my voice so well that customers think I wrote every post." |
| "I know I should be creating content but there are only so many hours in the day." | "I went on vacation for two weeks and the pipeline didn't slow down." |

### Pain Point 2: Content feels like a time sink with no measurable ROI

| Pain Quote | Pleasure Quote |
|---|---|
| "We published 30 blog posts last year and I can't point to a single deal from them." | "I can trace $180K in pipeline directly to three LinkedIn posts and a newsletter sequence." |
| "My agency sends me 'engagement reports' but none of that turns into revenue." | "Every piece of content has a clear job: generate awareness, capture intent, or nurture to demo." |
| "I don't need more impressions. I need more demos." | "Our content-to-demo conversion is 3.2% and climbing." |
| "Content marketing feels like planting trees I'll never live to see grow." | "We saw pipeline impact within 6 weeks of launching the new system." |
| "I can't justify spending money on content when I can't measure what it does." | "I know exactly which content drives pipeline and which is just noise." |

### Pain Point 3: AI tools produce generic output that sounds like everyone else

| Pain Quote | Pleasure Quote |
|---|---|
| "ChatGPT gives me perfectly fine copy that sounds like it was written by nobody." | "My AI workspace knows my voice, my audience, and my product. The output sounds like me on a good day." |
| "I tried AI for content and my co-founder asked why our blog suddenly sounded like a Wikipedia article." | "People DM me saying 'this post really resonated' and they have no idea AI helped write it." |
| "Every AI marketing tool promises '10x content' but it's 10x generic." | "I spend 20 minutes editing what Claude drafts instead of 3 hours writing from scratch." |
| "I don't want to sound like every other SaaS founder posting AI-generated LinkedIn fluff." | "My content has a point of view. That's what makes it work." |
| "If I have to read one more 'In today's fast-paced digital landscape' opener I'm going to lose it." | "My content rules file has one line: 'Never open with a cliche.' Claude follows it every time." |

### Pain Point 4: Marketing advice doesn't fit a small SaaS company

| Pain Quote | Pleasure Quote |
|---|---|
| "Every marketing playbook assumes I have a team of 10 and a $500K budget." | "This system was built for a founder and maybe one marketing person. That's us." |
| "HubSpot's blog tells me to 'build a content team.' I AM the content team." | "I run our entire content operation in 5 hours a week with AI doing 80% of the first draft work." |
| "Enterprise marketing advice is useless when you're trying to close 10 deals a month, not 10,000." | "Finally, a framework built for companies at my stage, not for companies I wish I was." |
| "I don't need a brand campaign. I need 3 more demos this week." | "Every piece of content maps to a stage in our buying process. Nothing is decorative." |
| "The gap between 'marketing best practice' and 'what works at $2M ARR' is enormous." | "I stopped reading marketing blogs and started running a system designed for my actual business." |

### Pain Point 5: Overwhelmed by the number of channels and tactics

| Pain Quote | Pleasure Quote |
|---|---|
| "LinkedIn, blog, newsletter, YouTube, podcast. I can't do all of them and I don't know which ones matter." | "We focus on LinkedIn and a weekly newsletter. That's it. And it's enough." |
| "Every week there's a new 'you HAVE to be on this platform' take and it makes me want to quit." | "My system ignores trends and focuses on the two channels that actually drive pipeline for us." |
| "I started a podcast, a blog, and a YouTube channel. All three are ghosts now." | "I'd rather dominate one channel than be mediocre on five." |
| "The paradox of choice in marketing is paralyzing." | "Having a weekly cadence means I never wonder 'what should I work on today.'" |
| "I keep starting things and not sustaining them." | "I've published consistently for 12 weeks straight. That's a record." |

---

## Language Notes

- Alex says "pipeline" not "leads" (B2B SaaS vocabulary)
- Alex says "demos" not "sales calls"
- Alex is allergic to marketing jargon like "synergy," "leverage," "ecosystem" used loosely
- Alex respects directness and data, distrusts hype
- Alex reads Lenny's Newsletter, First Round Review, SaaStr content
- Swears occasionally in casual conversation but keeps it professional in content
