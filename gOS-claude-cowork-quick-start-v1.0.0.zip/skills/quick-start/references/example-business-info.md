# Business Information — Greenline Digital

> This document is referenced by skills and workflows that need business context. Keep it updated when anything material changes.

Last updated: February 2026

---

## Business Identity

- **Brand name:** Greenline Digital
- **Tagline:** Pipeline that doesn't depend on you.
- **Legal entity:** Greenline Digital, LLC (Delaware, founded 2022)
- **Founded by:** Jamie Chen
- **Website:** https://greenlinedigital.com
- **Support email:** hello@greenlinedigital.com

## What We Do

Greenline Digital helps B2B SaaS founders build repeatable demand-generation engines using content marketing and AI tools. Our primary vehicle is the Greenline Growth Accelerator, a 12-week group coaching program. We also publish a free weekly newsletter covering B2B content strategy and founder marketing.

## Mission

We exist because most marketing advice is built for companies with big teams and big budgets. Greenline helps founders at $500K-$5M ARR generate pipeline without hiring an agency or building a 10-person marketing team. One founder, the right system, consistent execution.

## Target Audience

Our ideal customer is Alex, the Pipeline-Hungry Founder. Full persona details are in `core/persona.md`.

## Products & Offers

See `core/offers.md` for full details. Primary offer: Greenline Growth Accelerator ($4,500). Also: Content Audit ($1,200) and The Greenline Weekly (free newsletter, top of funnel).

## Key Platforms & Channels

| Channel | Purpose |
|---|---|
| Website | Hub for all content, sign-ups, and sales |
| Newsletter (ConvertKit) | Free weekly email; primary top-of-funnel |
| LinkedIn | Jamie's personal brand + content distribution |
| YouTube | Monthly deep-dive tutorials |

## Brand Voice

Direct, practical, slightly irreverent. Jamie talks to founders the way a sharp friend would: no fluff, no jargon, occasional humor. See `core/brand-voice.md` for the full guide.

## Tech Stack

| Tool | Role |
|---|---|
| ConvertKit | Email marketing and newsletter |
| Stripe | Payment processing |
| Claude (Cowork) | AI workspace for content and operations |
| Notion | Project management and task tracking |
| Figma | Design and visual content |
| Riverside | Podcast recording |

## Team

- **Jamie Chen** — Founder; handles strategy, content, coaching
- **Sam** — Part-time VA; handles scheduling and community moderation

## Metrics

- Newsletter subscribers: ~3,200
- Accelerator alumni: 85
- Current cohort: 12 participants
