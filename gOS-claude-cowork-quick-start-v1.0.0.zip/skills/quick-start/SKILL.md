---
name: quick-start
description: >
  This skill should be used when the user says "run the quick start",
  "quick start", "set up my workspace", "set up Growth OS for Claude Cowork", "continue setup",
  "get started", "build my workspace", or any variation of starting or
  continuing the Growth OS for Claude Cowork guided setup. Also triggers on "good morning"
  or session start if progress.md shows the Quick Start is incomplete.
version: 0.1.0
---

# Growth OS for Claude Cowork — Quick Start

Build a working AI workspace in one session. This skill walks the user through a guided setup that creates their core documents, scaffolds their folder structure, and delivers a personalized morning routine, so they can start using Claude as a daily business tool immediately.

## How It Works

The Quick Start has two tiers:

- **Tier 1 (Required):** Quick intake, offers document, persona document, morning routine. Completing these four steps means the Quick Start is DONE and the user gets a congratulations message.
- **Tier 2 (Optional Enhancements):** Business info, brand voice, brand design, content rules. These make the workspace better but are not required.

The user should hit "congratulations" fast. Do not gate completion on Tier 2 items.

## Progress & Tone

**Progress indicators:** At the start of each phase, show a simple progress line so the user always knows where they are. Format:

```
Step [N] of 6: [Phase Name]
```

The six steps are: Quick Intake, Offers, Persona, Morning Routine, CLAUDE.md, Workflows.

**Transitions between phases:** After completing each phase, give the user a one-line acknowledgment of what they just built and a short sentence about what's next. Keep it grounded. No exclamation-point storms, no "amazing" or "awesome." Just honest recognition that what they're building is real and useful.

Good examples:
- "That's your offers doc. Claude will reference this every time it writes about the business. On to your persona."
- "Persona's done. Those pain/pleasure quotes are going to make every piece of content sharper. Next up: your morning routine."
- "Your morning routine is set. Tomorrow morning, say 'good morning' and see it in action. Almost there."

Bad examples (too hype-y):
- "AMAZING work! You're absolutely crushing it! 🎉"
- "This is going to be INCREDIBLE for your business!"
- "You're building something truly extraordinary here!"

**Skip option on every step:** Every phase must include a skip option. When you present a phase to the user (via AskUserQuestion or otherwise), always include a "Skip this step" or "Skip for now" choice. If the user skips, mark it as skipped in `progress.md` (not complete), move to the next phase, and let them know they can come back to it later. No guilt, no friction. Some people want to get through the whole thing fast and fill in details later. That's fine.

**The overall tone:** You're a capable colleague helping someone set up a system that's going to save them real time and help them grow their business. Be warm, be direct, keep things moving. The work speaks for itself. You don't need to oversell it.

## Before You Begin

1. Check if a `progress.md` file exists in the workspace root. If it does, read it to determine where the user left off and resume from there. Do not restart steps already marked complete.
2. If no `progress.md` exists, this is a fresh start. Create it from the template in `references/progress-template.md`.
3. Read the example files in `references/` to understand what good output looks like. The examples use a fictional business called "Greenline Digital" so you can see the target format and depth.

## Folder Structure

Create this structure at the start (before any interviews). Use placeholder content in files that haven't been filled yet so the user can see the full shape of their workspace.

```
[workspace root]/
├── CLAUDE.md                          # Operational guide (generated at end of Tier 1)
├── progress.md                        # Setup progress tracker
├── core/
│   ├── offers.md                      # Tier 1: Products and pricing
│   ├── persona.md                     # Tier 1: Ideal customer persona
│   ├── business-info.md               # Tier 2: Business identity and context
│   ├── brand-voice.md                 # Tier 2: Writing voice guide
│   ├── brand-design.md                # Tier 2: Visual identity
│   └── content-rules.md              # Tier 2: Global writing rules
├── routines/
│   └── morning-routine.md             # Tier 1: Daily briefing routine
├── workflows/                         # Empty, ready for future skills
├── memory/
│   └── glossary.md                    # Quick decoder (generated with CLAUDE.md)
└── .claude/
    └── commands/
        └── morning-routine.md         # Slash command pointer
```

For files not yet completed, write a one-line placeholder: `<!-- Placeholder: This file will be created during [Tier 1/Tier 2] setup. -->`

## Phase 1: Quick Intake

Show: `Step 1 of 6: Quick Intake`

**Goal:** Gather the minimum information needed to crawl and pre-fill documents.

**IMPORTANT:** The user may be setting this up for their own business OR for a client's business. An agency owner, freelancer, or consultant might be building a workspace for a client they serve. Do not assume "the business" is the user's own. Always say "the business" rather than "your business" and let the user tell you whose it is.

Use AskUserQuestion to collect three things:

1. **Your name** (so Claude can greet you properly)
2. **The business name** (this might be the user's own business or a client's business)
3. **The business website URL** (Claude will crawl this to pre-fill documents)

Once you have these three answers:

1. Crawl the website using WebFetch. Pull the homepage plus any pages linked from the main nav (About, Services/Products, Pricing, Contact). Collect:
   - What the business sells (products, services, pricing if visible)
   - Who the business serves (audience language, industry terms)
   - How the business describes itself (tagline, mission, about copy)
   - Brand signals (tone of voice, any design elements described in text)

2. Store the crawl findings in memory for use in the next steps. Do not show the raw crawl to the user.

3. Create the full folder structure with placeholders.

4. Update `progress.md`: mark Quick Intake as complete.

If the website crawl fails or returns minimal content, that is fine. Proceed with interviews and ask the user directly. The crawl is a convenience, not a requirement.

## Phase 2: Offers Document (Tier 1 Required)

Show: `Step 2 of 6: Offers`

After the intake transition: "Good. I've got the site crawled and the folder structure ready. Now let's get the offers documented, so Claude always knows what the business sells."

**Goal:** Create `core/offers.md` with the business's products, pricing, and positioning.

**Reference:** Read `references/example-offers.md` to see what good looks like.

### Steps:

1. Draft `core/offers.md` using what you learned from the website crawl. Present the draft to the user and ask them to confirm or correct:
   - Product/service names
   - Pricing (or pricing model)
   - Who each offer is for
   - Primary offer (the one most content should drive toward)
   - Any free offers or lead magnets

2. Use AskUserQuestion for anything the crawl didn't cover. Keep questions specific, not open-ended. For example: "I found three products on your site: X, Y, and Z. Is that the full list, or are there others?" is better than "What do you sell?"

3. Write the final `core/offers.md` in clean markdown with sections for each offer.

4. Update `progress.md`: mark Offers as complete.

## Phase 3: Persona Document (Tier 1 Required)

Show: `Step 3 of 6: Persona`

After the offers transition: "That's your offers doc locked in. Claude will reference this every time it writes about the business. Now the persona, so Claude knows exactly who it's talking to."

**Goal:** Create `core/persona.md` with a deep ideal-customer profile including pain/pleasure quote tables.

**Reference:** Read `references/example-persona.md` to see the target format. Pay special attention to the quote tables: they are written IN the persona's voice, not ABOUT the persona.

### Steps:

1. Using the website crawl and offers doc, draft an initial persona profile:
   - Name (a first name that represents the archetype)
   - Demographics (age range, role, experience level)
   - One-line description
   - What they want (goals)
   - What frustrates them (pain points)

2. Present the draft and ask the user to react. Use AskUserQuestion: "Does this sound like the ideal customer? What would you change?" (Include "Skip this step" as an option.)

3. **Pain point selection (multi-select).** Based on the website crawl, the offers doc, and the persona draft, generate a list of 6-10 likely pain points for this persona. Present them using AskUserQuestion with `multiSelect: true` so the user can check all that apply. Always include an "Other" option so they can type in their own. Example:

   Question: "Which of these pain points hit closest to home for this persona? Check all that apply."
   Options (generated from context, not hardcoded):
   - "Spending hours on content that doesn't convert"
   - "No clear system for following up with leads"
   - "Knows they should use AI but doesn't know where to start"
   - "Posting on social but getting no engagement"
   (etc., tailored to the actual business)

   The user selects the ones that fit and can add their own via "Other."

4. Build the **pain/pleasure quote tables** from the selected pain points. For each pain point the user checked, create a pair:
   - **Pain quote:** What the persona says when they are struggling (written in first person, in their voice)
   - **Pleasure quote:** What the persona says when the problem is solved (written in first person, in their voice)

   Present the quote tables to the user for feedback. These should feel like real things a real person would say, not marketing copy.

5. Write the final `core/persona.md`.

6. Update `progress.md`: mark Persona as complete.

## Phase 4: Morning Routine (Tier 1 Required)

Show: `Step 4 of 6: Morning Routine`

After the persona transition: "Persona's done. Those pain/pleasure quotes are going to make every piece of content Claude writes sharper. Now let's build your morning routine, the thing you'll use every single day."

**Goal:** Create the morning routine file at `routines/morning-routine.md` and the slash command to trigger it.

**Reference:** Read `references/example-morning-routine.md` to see the format.

**IMPORTANT:** The morning routine MUST be written to `routines/morning-routine.md` inside the workspace. Verify this folder exists (it was created in the folder scaffolding step). If it doesn't exist, create it.

### Steps:

1. Use AskUserQuestion to learn what the user wants in their morning briefing:

   - "What does a productive morning look like for you? What information do you need first thing?" (options: Calendar overview, Weather, Task list, Industry news, Motivational/mindset, Custom)
   - "Do you have any daily affirmations, mantras, or mindset practices you'd like included?"
   - "What city are you in? (for weather)"

2. Build the morning routine with these sections (include only what the user wants, EXCEPT Suggested Tasks which is always included):
   - **Greeting** (always include, use the user's name)
   - **Day and date** (always include)
   - **Affirmation/manifesto** (if the user has one)
   - **Weather** (if requested, using their city)
   - **Calendar overview** (if Google Calendar MCP is connected)
   - **Task briefing** (if they have a task system)
   - **Industry news or content ideas** (if requested)
   - **Suggested Tasks** (ALWAYS include, see below)

   **Suggested Tasks section (required):** The morning routine must always end with a "Suggested Tasks" section. This gives the user three specific things they could work on today. The instructions FOR Claude in the routine file should say:

   > **Suggested Tasks:** Read all files in the workspace (core docs, any workflows, any recent outputs). Based on the current state of the business, the persona's pain points, any active workflows, and what hasn't been done recently, suggest 3 specific tasks the user could tackle today. Present them as numbered options, each with a one-sentence description of what it is and why it matters right now. These should feel like a smart colleague saying "here's what I'd work on today if I were you." Vary the suggestions day to day. Don't repeat the same three every morning.

3. Write the routine as a set of instructions FOR Claude, not as documentation for the user. Each step should tell Claude exactly what to do, what tools to use, and what format to present.

4. Write the completed routine to `routines/morning-routine.md`.

5. Create the slash command at `.claude/commands/morning-routine.md`:

   ```markdown
   ---
   description: Run your morning briefing routine
   allowed-tools: Read, WebSearch, WebFetch, Bash
   ---

   Read and execute the morning routine at routines/morning-routine.md.
   ```

6. Tell the user how to trigger it: "Say 'good morning' or type /morning-routine to run your daily briefing."

7. Update `progress.md`: mark Morning Routine as complete.

## Phase 5: Generate CLAUDE.md and Celebrate

Show: `Step 5 of 6: CLAUDE.md`

After the morning routine transition: "Your morning routine is set. Tomorrow morning, say 'good morning' and see it in action. Now I'm going to generate the file that ties everything together: CLAUDE.md. This is what Claude reads at the start of every session so it knows the business, the audience, and the daily rhythm."

**Goal:** Generate the operational guide and mark the Quick Start as complete.

### Steps:

1. Generate `CLAUDE.md` at the workspace root using the template in `references/claude-md-template.md`. Fill in all Tier 1 sections with the actual data from the documents created. Mark Tier 2 sections as "Not yet configured" with a note on how to add them later.

2. Generate `memory/glossary.md` with a quick-decoder section mapping the user's business terms, product names, and shorthand to plain definitions.

3. Update `progress.md`: mark CLAUDE.md and Glossary as complete. Mark overall Tier 1 as COMPLETE.

4. Present a congratulations message:

   ```
   Congratulations! Your Growth OS for Claude Cowork Quick Start is complete.

   Here's what you've built:
   - Offers document with your [N] products/services
   - Persona document with [N] pain/pleasure quote pairs
   - Personalized morning routine (say "good morning" to try it)
   - CLAUDE.md operational guide that ties it all together

   Your workspace is ready to use right now. Claude will read your
   CLAUDE.md on every session and know your business, your audience,
   and your daily rhythm.

   Want to make it even better? You can enhance your workspace with:
   - Brand voice guide (helps Claude write in your style)
   - Brand design guide (for visual output like emails and slides)
   - Business info document (deeper context about your company)
   - Content rules (global writing standards)

   Say "enhance my workspace" any time to add these.

   ---

   Russ would be proud. Take a screenshot of what you've built
   and post it on LinkedIn. Tag @Russ Henneberry so he can see it!
   ```

5. Do NOT automatically proceed to Tier 2. Instead, move directly to Phase 6.

## Phase 6: Suggest First Workflows

Show: `Step 6 of 6: Workflows`

This is the final step. It happens immediately after the congratulations message, as a natural next move.

**Goal:** Review everything built during the Quick Start and propose three logical workflow ideas for the `workflows/` folder.

### Steps:

1. Re-read the completed `core/offers.md` and `core/persona.md`. Consider:
   - What does this business sell? (product, service, coaching, SaaS, etc.)
   - Who is the persona and what are their pain points?
   - What growth channels would have the highest impact for this type of business?
   - What kinds of repeatable content or marketing processes would move the needle?

2. Infer THREE specific workflows that would be valuable for this business. Rank them by impact. Think about what the persona needs and what the business sells. Examples of workflows Claude can power:
   - **Weekly email newsletter** (for businesses that nurture via email)
   - **LinkedIn content pipeline** (for personal-brand-driven businesses)
   - **Lead follow-up sequences** (for service businesses or consultants)
   - **Content repurposing pipeline** (for businesses creating long-form content)
   - **Client onboarding checklist** (for agencies or service providers)
   - **Weekly social media batch** (for product or e-commerce businesses)
   - **Sales proposal generator** (for B2B services)
   - **Blog/SEO content pipeline** (for businesses that depend on organic traffic)
   - **Customer testimonial collector** (for businesses that rely on social proof)
   - **Webinar/event promotion pipeline** (for businesses that sell through events)

   Be specific for each one. Don't say "content marketing." Say "a weekly LinkedIn post pipeline that turns your client case studies into 3 posts per week."

3. Present all three ideas using AskUserQuestion. For each, give a name and 1-2 sentences explaining what it does and why it fits this business. Then ask:

   - "Which workflow should we build first?" (options: the three workflow names, plus "Not right now, maybe later")

4. **If the user picks a workflow:**
   - Create a `workflows/` subdirectory named for the workflow using kebab-case (e.g., `workflows/linkedin-content/` or `workflows/weekly-newsletter/`)
   - Create a `WORKFLOW.md` inside it with:
     - What the workflow does (2-3 sentences)
     - The repeatable steps (numbered, each step tells Claude what to do)
     - What inputs it needs from the user each time
     - What it produces as output
     - An `outputs/` subfolder for the workflow's deliverables
   - Write the workflow instructions FOR Claude (just like the morning routine: directives, not documentation)
   - Update `CLAUDE.md` to reference the new workflow
   - Update `progress.md` to log the workflow creation
   - After building it, let the user know the other two workflow ideas are still available: "Say 'build a workflow' any time to add another one."

5. **If the user says "not right now":**
   - That's fine. Let them know all three suggestions are saved and they can say "build a workflow" any time. Move on.

## Tier 2: Optional Enhancements

When the user says "enhance my workspace", "add brand voice", "set up brand design", or any variation, run the relevant enhancement. Each one is independent; they can be done in any order.

### Enhancement: Business Info

1. Draft `core/business-info.md` using the website crawl and everything learned during Tier 1.
2. Present the draft and ask the user to fill in gaps (mission, team, tech stack, key channels).
3. Write the final file.
4. Update `progress.md` and regenerate the relevant sections of `CLAUDE.md`.

### Enhancement: Brand Voice

1. Use AskUserQuestion:
   - "How would you describe your writing style in 3-5 words?"
   - "Share a paragraph you've written that sounds like YOU at your best (a social post, email, bio, anything)."
   - "What tone do you want to avoid? (e.g., corporate, overly casual, salesy)"

2. If the user provides a writing sample, analyze it for: sentence length patterns, vocabulary preferences, rhetorical habits, tone markers.

3. Draft `core/brand-voice.md` with sections for: voice summary, vocabulary preferences, sentence patterns, things to avoid, and a before/after example showing generic copy vs. the user's voice.

4. Update `progress.md` and CLAUDE.md.

### Enhancement: Brand Design

1. Ask about or pull from website: primary colors, fonts, logo description, general aesthetic.
2. Draft `core/brand-design.md` with: color palette (with hex codes), typography, layout preferences, and usage rules.
3. Update `progress.md` and CLAUDE.md.

### Enhancement: Content Rules

1. Ask: "Are there any writing rules you always follow? For example: never use certain words, always write in a certain style, specific formatting requirements?"
2. Draft `core/content-rules.md` with global rules that apply to all content Claude produces.
3. Update `progress.md` and CLAUDE.md.

## Session Continuity

This skill MUST support multi-session completion. Every step updates `progress.md` immediately after finishing. On any new session:

1. Read `progress.md` to determine current state
2. Resume from the first incomplete step
3. Do not re-ask questions for completed steps
4. If the user says "continue setup" or "where was I", read progress.md and pick up where they left off

## Writing Guidelines

- **Tone with the user:** Warm, direct, and grounded. You're helping them build something that's going to make a real difference in how they run and grow a business. That's worth being encouraging about, but let the work do the talking. No hype, no exclamation-point storms, no "amazing" or "awesome." Just honest recognition and forward momentum. This is onboarding, not an exam. Keep it moving.
- **AskUserQuestion usage:** Use it for every question. Never dump a wall of questions as plain text. Keep to 1-2 questions per interaction to maintain momentum.
- **Website crawl as draft:** Always present crawl-based drafts as "Here's what I found on your site. Does this look right?" Never assume the crawl is authoritative.
- **Documents are for Claude:** The files you create (offers.md, persona.md, etc.) are reference documents that Claude reads to do better work. Write them as clean, structured reference material, not as marketing copy.
- **Examples, not blanks:** When showing the user what a section should contain, refer to the Greenline Digital examples in `references/`. Never show empty templates.

## Additional Resources

- **`references/example-offers.md`** - Example offers document (Greenline Digital)
- **`references/example-persona.md`** - Example persona with pain/pleasure quote tables
- **`references/example-morning-routine.md`** - Example morning routine
- **`references/example-business-info.md`** - Example business info document
- **`references/example-brand-voice.md`** - Example brand voice guide
- **`references/example-brand-design.md`** - Example brand design guide
- **`references/progress-template.md`** - Progress tracker template
- **`references/claude-md-template.md`** - CLAUDE.md template
